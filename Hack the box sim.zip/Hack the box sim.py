import sys
import hashlib
import random
import string
import time
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QLineEdit, QComboBox, QTextEdit
from PyQt5.QtCore import Qt

# Machine Class (Simulates Machines with Vulnerabilities)
class Machine:
    def __init__(self, name, vulnerability, difficulty):
        self.name = name
        self.vulnerability = vulnerability
        self.status = "offline"
        self.password = self.generate_password()
        self.difficulty = difficulty

    def start(self):
        self.status = "online"
        return f"Machine {self.name} is online!"

    def stop(self):
        self.status = "offline"
        return f"Machine {self.name} is offline."

    def generate_password(self):
        """Generate a weak password for the machine."""
        if self.vulnerability == "weak_password":
            return "password123"
        elif self.vulnerability == "sql_injection":
            return "admin' OR '1'='1"
        return "securepassword"

    def simulate_sql_injection(self):
        """Simulate SQL injection vulnerability."""
        if self.vulnerability == "sql_injection":
            return "Database vulnerable, hack successful!"
        return "SQL Injection failed"

    def simulate_weak_password(self, entered_password):
        """Simulate password cracking."""
        if self.vulnerability == "weak_password" and entered_password == self.password:
            return "Password cracked!"
        return "Incorrect password"

# Exploit Challenges (SQL Injection and Password Cracking)
class ExploitChallenges:
    @staticmethod
    def sql_injection_simulation(machine):
        return f"Attempting SQL Injection on {machine.name}...\n{machine.simulate_sql_injection()}"

    @staticmethod
    def password_cracking_simulation(machine, entered_password):
        return f"Attempting to crack password for {machine.name}...\n{machine.simulate_weak_password(entered_password)}"

# Scoring System
class ScoreSystem:
    def __init__(self):
        self.score = 0
        self.level = "Beginner"

    def update_score(self, points, difficulty):
        # Increase points based on difficulty
        if difficulty == "Medium":
            points *= 1.5
        elif difficulty == "Hard":
            points *= 2

        self.score += points
        self.update_level()
        return self.score

    def update_level(self):
        """Update player's progress level based on the score."""
        if self.score < 100:
            self.level = "Beginner"
        elif self.score < 250:
            self.level = "Intermediate"
        else:
            self.level = "Advanced"

# Password Generator Tool
class PasswordGenerator:
    def __init__(self, machine):
        self.machine = machine

    def generate_passwords(self):
        """Generate 10 random passwords and set one as the correct server password."""
        passwords = []
        for _ in range(10):
            password = self._generate_random_password()
            passwords.append(password)

        # Set the correct password randomly among the generated passwords
        correct_password = random.choice(passwords)
        self.machine.password = correct_password  # Correct password for the server
        return passwords

    def _generate_random_password(self):
        """Generate a random password consisting of letters and digits."""
        length = random.randint(8, 12)
        characters = string.ascii_letters + string.digits + string.punctuation
        return ''.join(random.choice(characters) for i in range(length))

# Main GUI Class for the Hack The Box Simulator
class HTBSimulatorGUI(QWidget):
    def __init__(self):
        super().__init__()

        # Initialize machines before calling initUI()
        self.machines = [
            Machine("WebServer1", "weak_password", "Easy"),
            Machine("SQLServer1", "sql_injection", "Medium"),
            Machine("FileServer1", "weak_password", "Hard"),
            Machine("DatabaseServer1", "sql_injection", "Medium"),
            Machine("AppServer1", "weak_password", "Easy"),
            Machine("WebServer2", "sql_injection", "Hard"),
        ]
        
        self.exploits = ExploitChallenges()
        self.score_system = ScoreSystem()
        
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Hack The Box Simulator")
        self.setGeometry(100, 100, 600, 400)

        # Set the overall style (black background, green buttons)
        self.setStyleSheet("""
            QWidget {
                background-color: black;
                color: white;
                font-size: 14px;
            }
            QPushButton {
                background-color: green;
                color: white;
                border-radius: 5px;
                padding: 10px;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: darkgreen;
            }
            QComboBox, QLineEdit {
                background-color: #333;
                color: white;
                border: 1px solid #555;
                border-radius: 5px;
                padding: 5px;
            }
            QLabel {
                color: white;
                font-size: 16px;
                padding: 5px;
            }
            QTextEdit {
                background-color: #111;
                color: #00FF00;
                border: 1px solid #555;
                font-family: "Courier New", Courier, monospace;
                font-size: 14px;
                padding: 5px;
            }
        """)

        layout = QVBoxLayout()

        # Create and add widgets
        self.status_label = QLabel("Select an action from the menu", self)
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)

        self.machine_combo = QComboBox(self)
        self.machine_combo.addItem("Select Machine")
        for machine in self.machines:
            self.machine_combo.addItem(machine.name)
        layout.addWidget(self.machine_combo)

        self.password_input = QLineEdit(self)
        self.password_input.setPlaceholderText("Enter password (if required)")
        layout.addWidget(self.password_input)

        self.start_button = QPushButton('Start Machine', self)
        self.start_button.clicked.connect(self.start_machine)
        layout.addWidget(self.start_button)

        self.stop_button = QPushButton('Stop Machine', self)
        self.stop_button.clicked.connect(self.stop_machine)
        layout.addWidget(self.stop_button)

        self.exploit_button = QPushButton('Attempt Exploit', self)
        self.exploit_button.clicked.connect(self.attempt_exploit)
        layout.addWidget(self.exploit_button)

        self.generate_password_button = QPushButton('Generate Passwords', self)
        self.generate_password_button.clicked.connect(self.generate_passwords)
        layout.addWidget(self.generate_password_button)

        self.console_button = QPushButton('Console', self)
        self.console_button.clicked.connect(self.toggle_console)
        layout.addWidget(self.console_button)

        self.score_label = QLabel("Current Score: 0", self)
        self.score_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.score_label)

        self.level_label = QLabel("Level: Beginner", self)
        self.level_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.level_label)

        # Console area (hidden by default)
        self.console = QTextEdit(self)
        self.console.setReadOnly(True)
        self.console.setVisible(False)
        layout.addWidget(self.console)

        self.setLayout(layout)

    def start_machine(self):
        selected_machine_name = self.machine_combo.currentText()
        machine = next((m for m in self.machines if m.name == selected_machine_name), None)
        
        if machine:
            result = machine.start()
            self.log_to_console(result)
            self.status_label.setText(f"Machine {machine.name} started successfully!")
        else:
            self.status_label.setText("Please select a machine first.")

    def stop_machine(self):
        selected_machine_name = self.machine_combo.currentText()
        machine = next((m for m in self.machines if m.name == selected_machine_name), None)
        
        if machine:
            result = machine.stop()
            self.log_to_console(result)
            self.status_label.setText(f"Machine {machine.name} stopped successfully!")
        else:
            self.status_label.setText("Please select a machine first.")

    def attempt_exploit(self):
        selected_machine_name = self.machine_combo.currentText()
        machine = next((m for m in self.machines if m.name == selected_machine_name), None)
        
        if machine:
            if machine.vulnerability == "weak_password":
                entered_password = self.password_input.text()
                result = self.exploits.password_cracking_simulation(machine, entered_password)
                self.log_to_console(result)
                self.status_label.setText(result)
                if result == "Password cracked!":
                    points = random.randint(10, 30)
                    self.score_system.update_score(points, machine.difficulty)
                    self.score_label.setText(f"Current Score: {self.score_system.score}")
            elif machine.vulnerability == "sql_injection":
                result = self.exploits.sql_injection_simulation(machine)
                self.log_to_console(result)
                self.status_label.setText(result)
                points = random.randint(10, 30)
                self.score_system.update_score(points, machine.difficulty)
                self.score_label.setText(f"Current Score: {self.score_system.score}")
        else:
            self.status_label.setText("Please select a machine first.")

    def generate_passwords(self):
        selected_machine_name = self.machine_combo.currentText()
        machine = next((m for m in self.machines if m.name == selected_machine_name), None)
        
        if machine:
            password_generator = PasswordGenerator(machine)
            passwords = password_generator.generate_passwords()
            self.log_to_console("Generated Passwords:")
            for i, password in enumerate(passwords, 1):
                self.log_to_console(f"{i}. {password}")
            self.status_label.setText("Generated 10 passwords. Try to crack the password!")
        else:
            self.status_label.setText("Please select a machine first.")

    def toggle_console(self):
        self.console.setVisible(not self.console.isVisible())
    
    def log_to_console(self, text):
        self.console.append(text)
        self.console.moveCursor(self.console.textCursor().End)

# Main Execution
if __name__ == "__main__":
    app = QApplication(sys.argv)
    simulator_gui = HTBSimulatorGUI()
    simulator_gui.show()
    sys.exit(app.exec_())
